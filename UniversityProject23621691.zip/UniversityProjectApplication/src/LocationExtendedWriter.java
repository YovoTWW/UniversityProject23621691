public class LocationExtendedWriter extends BaseWriter{
    @Override
    public void Write(String word) {
        System.out.println("Напишете новата локация и името на файла след '"+word+"'");
    }

    public LocationExtendedWriter() {
    }
}
