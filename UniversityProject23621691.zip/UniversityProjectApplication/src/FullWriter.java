public class FullWriter extends BaseWriter{
    @Override
    public void FullWrite(String sentence) {
        System.out.println(sentence);
    }

    public FullWriter() {
    }
}
