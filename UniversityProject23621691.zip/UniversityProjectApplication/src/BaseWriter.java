public abstract class BaseWriter {
    public void Write(String word){};

    public void FullWrite(String sentence){};

    public BaseWriter() {
    }
}
